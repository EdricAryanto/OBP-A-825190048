public class Main {
    public static void main(String[] args) {

    mobil mobil = new mobil();

        mobil.merek = "toyota";

        mobil.name = "avanza";

        mobil.speed = 40;

        mobil.fuel = 40;

        System.out.println("merek mobil = " + mobil.merek);

        System.out.println("nama mobil = " + mobil.name);

        System.out.println("jumlah bensin  = " + mobil.fuel);

        System.out.println("kecepatan mobil = " + mobil.speed);

        mobil.run();

        mobil.speed();

        mobil.stop();

        mobil.gas();

    }
}