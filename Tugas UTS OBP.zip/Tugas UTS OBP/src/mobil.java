import java.util.Scanner;

public class mobil {
    
    int fuel;
    int speed;
    String name;
    String merek;

    public void run() {

        System.out.println(name + " is start...");

        System.out.println("Speed: " + speed);
    }


    public void speed() {
        if (speed > 40) {

            System.out.println("your car is normal.....");

        } else {

            System.out.println("your car is too slow.....");

            System.out.println("increase the speed of your car.....");
        }
    }


    public void stop() {
        if (speed > 0) {

            System.out.println("the engine cannot be turned off.....");

        } else {

            System.out.println("the engine has been turned off.....");
        }
    }

     public void gas () {
        if (fuel > 40){

            System.out.println("fuel is normal.....");

            speed--;

        }else{

            System.out.println("fuel is low.....");

            System.out.println("come to gas station.....");
        }

    }
}

