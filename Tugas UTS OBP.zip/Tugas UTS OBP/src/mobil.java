import java.util.Scanner;

public class mobil {
    
    int fuel;
    int speed;
    String name;
    String merek;

    public void run() {

        System.out.println(name + " is start...");

        System.out.println("Speed: " + speed);
    }


    public void speed() {
        if (speed > 30) {

            System.out.println("mobil dalam kecepatan normal.....");

        } else {

            System.out.println("mobil dalam kecepatan terlalu rendah.....");

            System.out.println("tambah kecepatan mobil .....");
        }
    }


    public void stop() {
        if (speed > 0) {

            System.out.println("mesin tidak bisa dimatikan.....");

        } else {

            System.out.println("mesin telah dimatikan.....");
        }
    }

     public void gas () {
        if (fuel > 40){

            System.out.println("bensin dalam keadaan cukup.....");

        }else{

            System.out.println("bensin dalam keadaan rendah.....");

            System.out.println("datang ke pom bensin.....");
        }

    }
}

